
<body>
<h1>Subjects List</h1>
<button class="btn btn-danger" data-toggle="modal" data-target="#adSubjMod">Add Subject</button>


<!-- Start Modal For Add Subject-->
<div id="adSubjMod" class="modal fade" role="dialog">
	<div class="modal-dialog">

	<!-- Modal Content For Edit-->
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<div class="box-title">
			<h3>
			<i class="fa fa-edit"></i>
			Add Subject
			</h3>
			</div>
		</div>
		<div class="modal-body">
			<div class="box-content">        
			<form id="form" action="<?php echo e(URL::to('addsubject')); ?>" method="POST" class='form-horizontal' enctype="multipart/form-data">

			<div class="form-group">
			<label for="textfield" class="control-label col-sm-2">Subject Name:</label>
			<div class="col-sm-10">
			<input type="text" id="subject" name="subject" class="form-control" required>
			
			
			</div>
			</div>	

			
			</div>
		</div>
		<div class="modal-footer">
			<input type="submit" id="submit" name="btn" class="btn btn-primary pull-left " value="Save Record" /> 
			</form>
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	</div>

	</div>
</div>
<!-- End Modal For Add Subject Model-->
</body>
<script type="text/javascript">
	
	$.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
        });
  var APP_URL = <?php echo json_encode(url('/')); ?>;
  //------------add subject------------------
   $(document).on('submit','#form',function(){
    var subject = $('#subject').val();
    alert(subject);
    console.log(subject);
     $.post(APP_URL+'/addsubject',{subject:subject},function(data)
        {
            console.log(data);
            
            }); 
 
    });




</script>