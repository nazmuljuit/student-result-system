<h1>Student List</h1>

<button class="btn btn-danger" data-toggle="modal" data-target="#adSubjMod">Add Student</button>


<!-- Start Modal For Add Student-->
<div id="adSubjMod" class="modal fade" role="dialog">
	<div class="modal-dialog">

	<!-- Modal Content For Edit-->
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<div class="box-title">
			<h3>
			<i class="fa fa-edit"></i>
			Add Student
			</h3>
			</div>
		</div>
		<div class="modal-body">
			<div class="box-content">        
			<form id="form" action="<?php echo e(URL::to('addstudent')); ?>" method="POST" class='form-horizontal' enctype="multipart/form-data">

			<div class="form-group">
			<label for="textfield" class="control-label col-sm-2">Student Name:</label>
			<div class="col-sm-10">
			<input type="text" name="subject" class="form-control" required>
			
			
			</div>
			</div>	

			
			</div>
		</div>
		<div class="modal-footer">
			<input type="submit" id="submit" name="btn" class="btn btn-primary pull-left qtype_submit" value="Save Record" /> 
			</form>
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	</div>

	</div>
</div>
<!-- End Modal For Add Student Model-->